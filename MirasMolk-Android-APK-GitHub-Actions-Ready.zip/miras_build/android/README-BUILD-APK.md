# MirasMolk Android APK

این پروژه برای ساخت خودکار APK با GitHub Actions آماده شده است.

## ساخت APK در GitHub
1. کل محتویات این پوشه را در یک repository جدید GitHub قرار دهید.
2. از مسیر **Actions → Build MirasMolk APK → Run workflow** اجرا کنید.
3. پس از پایان موفق، در صفحه همان اجرای Workflow بخش **Artifacts** فایل `MirasMolk-Secretary-APK` را دانلود کنید.

Workflow از JDK 17، Android SDK 35 و Gradle 8.13 استفاده می‌کند.
