#!/bin/bash
set -e
if [ -f ./gradlew ]; then
  chmod +x ./gradlew
  ./gradlew --no-daemon assembleRelease
else
  gradle --no-daemon assembleRelease
fi
echo "APK: app/build/outputs/apk/release/app-release-unsigned.apk"
