@echo off
chcp 65001 > nul
echo ==========================================================
echo     در حال آماده سازی و ساخت APK منشی هوشمند میراث ملک   
echo ==========================================================

if exist "gradlew.bat" (
    echo [+] در حال کامپایل پروژه با Gradlew...
    call gradlew.bat assembleRelease
) else (
    echo [+] در حال کامپایل با gradle...
    call gradle assembleRelease
)

echo [✓] عملیات به پایان رسید. فایل خروجی در مسیر:
echo app\build\outputs\apk\release\app-release-unsigned.apk
pause
